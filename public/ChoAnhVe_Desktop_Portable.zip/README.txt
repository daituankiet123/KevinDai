💖 ỨNG DỤNG "CHỜ ANH VỀ" - BẢN ĐÓNG GÓI CHẠY TRÊN MỌI MÁY TÍNH (OFFLINE 100%)
=======================================================================
Cặp đôi: Đại Tuấn Kiệt & Lê Thị Thanh Tuyền
Đơn vị: Trường Cao đẳng Hậu cần 2, TP. Thủ Đức (2026 - 2028)

CÁCH SỬ DỤNG:
1. Nhấp đúp chuột vào file "Chay_Ung_Dung_Windows.bat" (hoặc nhấp đúp trực tiếp vào file "index.html").
2. Ứng dụng sẽ tự động mở trên trình duyệt mặc định (Chrome, Edge, Firefox, Cốc Cốc).
3. Nếu bạn muốn chạy qua giao thức HTTP cục bộ bằng Node.js, nhấp đúp "Chay_Server_NodeJS.bat".
4. Trên macOS / Linux: Chạy file "Chay_Ung_Dung_Mac_Linux.sh".
5. Hoạt động 100% Offline, không yêu cầu kết nối Internet.
