#!/bin/sh
cd "$(dirname "$0")"
if which xdg-open >/dev/null 2>&1; then
  xdg-open index.html
elif which open >/dev/null 2>&1; then
  open index.html
else
  node serve.mjs
fi
